Documentary Film Content Package
			Generated on: 2024-10-27 13:41:15
			Video: Doc_1_Anchored

			Contents:
			1. Transcript and Chapters (JSON)
			2. Chapter Video Clips
			3. Generated Content:
			- Summary
			- Target Audience Analysis
			- Discussion Guide
			- Social Media Posts

			Note: This package contains all available generated content at the time of export.
		