Documentary Film Content Package
Generated on: 2024-10-27 13:58:13
Video: Doc_1_Anchored

Package Contents:
----------------
1. Transcript Data:
   - Doc_1_Anchored_transcript.json

2. Chapter Clips:
   - chapter_1_Doc_1_Anchored.mp4
     Gist: Living On A Houseboat
   - chapter_2_Doc_1_Anchored.mp4
     Gist: Some people live on boats in Richardson's Bay
   - chapter_3_Doc_1_Anchored.mp4
     Gist: Marriage Made in Hell
   - chapter_4_Doc_1_Anchored.mp4
     Gist: Living on a Dragon

3. Generated Content:
   - Doc_1_Anchored_summary.txt
   - Doc_1_Anchored_target_audience.txt
   - Doc_1_Anchored_discussion_guide.txt
   - Doc_1_Anchored_social_posts.txt
   - Doc_1_Anchored_impact_orgs.txt